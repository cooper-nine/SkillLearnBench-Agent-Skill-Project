---
name: tsv-analysis
description: Skills for analyzing 13F filing TSV data including fuzzy search, fund lookup, and holdings analysis.
---

# TSV Analysis Skills for 13F Filings

## Overview
This skill covers techniques for analyzing SEC 13F filing data stored in TSV format, including:
- Fuzzy searching COVERPAGE for fund names
- Extracting AUM and fund details from SUBMISSION table
- Analyzing holdings from INFOTABLE
- Comparing holdings across quarters

## Data Structure

### COVERPAGE.tsv
Contains fund manager information with columns:
- ACCESSION_NUMBER: Unique identifier for each filing
- FILINGMANAGER_NAME: Name of the fund manager
- REPORTCALENDARORQUARTER: Reporting period

### SUBMISSION.tsv
Contains submission details with columns:
- ACCESSION_NUMBER: Links to COVERPAGE
- CIK: Central Index Key
- PERIODOFREPORT: Report period date

### INFOTABLE.tsv
Contains holdings information with columns:
- ACCESSION_NUMBER: Links to filing
- NAMEOFISSUER: Stock name
- CUSIP: Stock identifier
- VALUE: Dollar value of holding (in thousands)
- SSHPRNAMT: Number of shares

## Installation

```bash
pip install pandas fuzzywuzzy python-Levenshtein
```

## Usage Patterns

### 1. Fuzzy Search for Fund Name
```python
import pandas as pd
from fuzzywuzzy import fuzz, process

# Load COVERPAGE
coverpage = pd.read_csv('COVERPAGE.tsv', sep='\t')

# Fuzzy search for fund name
def find_fund_accession(coverpage, search_term, quarter_file):
    matches = []
    for idx, row in coverpage.iterrows():
        score = fuzz.ratio(search_term.lower(), row['FILINGMANAGER_NAME'].lower())
        if score > 70:
            matches.append((row['ACCESSION_NUMBER'], row['FILINGMANAGER_NAME'], score))
    
    # Sort by score descending
    matches.sort(key=lambda x: x[2], reverse=True)
    return matches[0] if matches else None
```

### 2. Get Fund AUM from SUBMISSION
```python
# Load SUBMISSION
submission = pd.read_csv('SUBMISSION.tsv', sep='\t')

# Get AUM for specific accession number
def get_fund_aum(submission, accession_number):
    row = submission[submission['ACCESSION_NUMBER'] == accession_number]
    if len(row) > 0:
        return row.iloc[0]['ENTIRETY']  # AUM field
    return None
```

### 3. Get Holdings from INFOTABLE
```python
# Load INFOTABLE
infotable = pd.read_csv('INFOTABLE.tsv', sep='\t')

# Get all holdings for a fund
def get_holdings(infotable, accession_number):
    holdings = infotable[infotable['ACCESSION_NUMBER'] == accession_number]
    return holdings[['CUSIP', 'NAMEOFISSUER', 'VALUE', 'SSHPRNAMT']]
```

### 4. Compare Holdings Between Quarters
```python
def compare_holdings(q2_holdings, q3_holdings):
    # Merge on CUSIP
    merged = pd.merge(q2_holdings, q3_holdings, on='CUSIP', how='outer', suffixes=('_q2', '_q3'))
    merged['value_change'] = merged['VALUE_q3'].fillna(0) - merged['VALUE_q2'].fillna(0)
    
    # Find increased investments
    increased = merged[merged['value_change'] > 0].sort_values('value_change', ascending=False)
    return increased
```

### 5. Find Top Investors in a Stock
```python
def find_top_investors(infotable, cusip, top_n=3):
    stock_holdings = infotable[infotable['CUSIP'] == cusip]
    
    # Join with COVERPAGE to get fund manager names
    merged = pd.merge(stock_holdings, coverpage[['ACCESSION_NUMBER', 'FILINGMANAGER_NAME']], 
                      on='ACCESSION_NUMBER')
    
    # Sort by value and get top N
    top = merged.sort_values('VALUE', ascending=False).head(top_n)
    return top['FILINGMANAGER_NAME'].tolist()
```

## Example Workflow

```python
import pandas as pd
from fuzzywuzzy import fuzz

# Load data
coverpage_q3 = pd.read_csv('/root/2025-q3/COVERPAGE.tsv', sep='\t')
submission_q3 = pd.read_csv('/root/2025-q3/SUBMISSION.tsv', sep='\t')
infotable_q3 = pd.read_csv('/root/2025-q3/INFOTABLE.tsv', sep='\t')

# Step 1: Find Renaissance Technologies
matches = []
for idx, row in coverpage_q3.iterrows():
    score = fuzz.ratio('renaissance technologies', row['FILINGMANAGER_NAME'].lower())
    if score > 70:
        matches.append((row['ACCESSION_NUMBER'], row['FILINGMANAGER_NAME'], score))

best_match = sorted(matches, key=lambda x: x[2], reverse=True)[0]
accession = best_match[0]

# Step 2: Get AUM
aum_row = submission_q3[submission_q3['ACCESSION_NUMBER'] == accession]
aum = aum_row['ENTIRETY'].values[0] if len(aum_row) > 0 else None

# Step 3: Count holdings
holdings = infotable_q3[infotable_q3['ACCESSION_NUMBER'] == accession]
num_stocks = len(holdings)
```
