---
name: pandas-operations
description: Essential pandas operations for data manipulation, merging, and aggregation in financial analysis.
---

# Pandas Operations for Financial Analysis

## Installation
```bash
pip install pandas numpy
```

## Key Operations

### 1. Loading TSV Files
```python
import pandas as pd

df = pd.read_csv('file.tsv', sep='\t')
```

### 2. Filtering Data
```python
# Filter by column value
filtered = df[df['ACCESSION_NUMBER'] == '0001214659-25-015655']

# Filter by multiple conditions
filtered = df[(df['VALUE'] > 1000) & (df['CUSIP'].notna())]
```

### 3. Merging DataFrames
```python
# Inner join
merged = pd.merge(df1, df2, on='ACCESSION_NUMBER', how='inner')

# Left join
merged = pd.merge(df1, df2, on='CUSIP', how='left')

# Outer join with suffixes
merged = pd.merge(q2_holdings, q3_holdings, on='CUSIP', how='outer', 
                  suffixes=('_q2', '_q3'))
```

### 4. Aggregation
```python
# Group by and sum
grouped = df.groupby('CUSIP')['VALUE'].sum().reset_index()

# Count unique values
count = df['CUSIP'].nunique()
```

### 5. Sorting
```python
# Sort descending
sorted_df = df.sort_values('VALUE', ascending=False)

# Sort by multiple columns
sorted_df = df.sort_values(['VALUE', 'CUSIP'], ascending=[False, True])
```

### 6. Handling Missing Values
```python
# Fill NaN with 0
df['VALUE'] = df['VALUE'].fillna(0)

# Drop rows with NaN
df = df.dropna(subset=['CUSIP'])
```

### 7. Calculating Changes
```python
# Calculate difference between quarters
df['value_change'] = df['VALUE_q3'] - df['VALUE_q2']

# Percentage change
df['pct_change'] = (df['VALUE_q3'] - df['VALUE_q2']) / df['VALUE_q2'] * 100
```
