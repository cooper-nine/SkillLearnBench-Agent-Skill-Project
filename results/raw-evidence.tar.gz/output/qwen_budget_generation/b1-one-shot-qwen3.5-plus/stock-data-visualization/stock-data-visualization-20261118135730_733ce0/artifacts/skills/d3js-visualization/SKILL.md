---
name: d3js-visualization
description: Guide for creating interactive D3.js v6 visualizations including force-directed bubble charts, tooltips, legends, and linked interactions.
---

# D3.js v6 Visualization Skills

## Overview
This skill covers creating interactive data visualizations using D3.js version 6, focusing on:
- Force-directed bubble charts with clustering
- Tooltips and hover interactions
- Legend creation using HTML div elements
- Linked interactions between chart and table
- Proper SVG element usage

## Installation/Setup

Include D3.js v6 in your HTML:
```html
<script src="https://d3js.org/d3.v6.min.js"></script>
```

Or use a local copy:
```html
<script src="js/d3.v6.min.js"></script>
```

## Force-Directed Bubble Chart with Sector Clustering

### Basic Structure
```javascript
// Create SVG
const svg = d3.select("#chart")
    .append("svg")
    .attr("width", width)
    .attr("height", height);

// Create simulation with forces
const simulation = d3.forceSimulation(data)
    .force("charge", d3.forceManyBody().strength(-50))
    .force("collide", d3.forceCollide(d => rScale(d.value) + 2))
    .force("x", d3.forceX(width / 2).strength(1))
    .force("y", d3.forceY(height / 2).strength(1));

// Add sector-based clustering
const sectors = [...new Set(data.map(d => d.sector))];
sectors.forEach((sector, i) => {
    const angle = (i / sectors.length) * 2 * Math.PI;
    const x = width / 2 + Math.cos(angle) * 150;
    const y = height / 2 + Math.sin(angle) * 150;
    
    simulation.force(`x-${sector}`, 
        d3.forceX(x).strength(d => d.sector === sector ? 0.8 : 0));
    simulation.force(`y-${sector}`, 
        d3.forceY(y).strength(d => d.sector === sector ? 0.8 : 0));
});
```

### Creating Bubbles (Only Stock Circles)
```javascript
// IMPORTANT: Only create <circle> elements for actual stock bubbles
const circles = svg.selectAll("circle")
    .data(data)
    .enter()
    .append("circle")
    .attr("r", d => d.isETF ? 20 : rScale(d.marketCap))
    .attr("fill", d => colorScale(d.sector))
    .attr("stroke", "#333")
    .attr("stroke-width", 1);

// Add text labels inside bubbles
const labels = svg.selectAll("text")
    .data(data)
    .enter()
    .append("text")
    .attr("text-anchor", "middle")
    .attr("dy", ".3em")
    .text(d => d.ticker);
```

### Tooltip Implementation
```javascript
// Create tooltip div
const tooltip = d3.select("body")
    .append("div")
    .attr("class", "tooltip")
    .style("opacity", 0)
    .style("position", "absolute")
    .style("background", "#333")
    .style("color", "#fff")
    .style("padding", "8px")
    .style("border-radius", "4px");

// Hover events (skip ETFs)
circles.on("mouseover", function(event, d) {
    if (d.isETF) return; // Skip ETFs
    tooltip.transition().duration(200).style("opacity", 0.9);
    tooltip.html(`
        <strong>${d.ticker}</strong><br/>
        ${d.name}<br/>
        ${d.sector}
    `)
    .style("left", (event.pageX + 10) + "px")
    .style("top", (event.pageY - 28) + "px");
})
.on("mouseout", function() {
    tooltip.transition().duration(500).style("opacity", 0);
});
```

### Legend as Div Element
```javascript
// Create legend container
const legend = d3.select("#legend")
    .selectAll(".legend-item")
    .data(sectors)
    .enter()
    .append("div")
    .attr("class", "legend-item")
    .style("display", "inline-block")
    .style("margin-right", "15px");

// Add color swatch
legend.append("span")
    .attr("class", "legend-color")
    .style("display", "inline-block")
    .style("width", "20px")
    .style("height", "20px")
    .style("background-color", d => colorScale(d))
    .style("margin-right", "5px")
    .style("vertical-align", "middle");

// Add label
legend.append("span")
    .text(d => d);
```

### Linked Interactions (Chart ↔ Table)
```javascript
// Click on bubble highlights table row
circles.on("click", function(event, d) {
    // Remove previous highlights
    d3.selectAll("tr").classed("highlighted", false);
    d3.selectAll("circle").classed("highlighted", false);
    
    // Highlight selected
    d3.select(this).classed("highlighted", true);
    d3.select(`#row-${d.ticker}`).classed("highlighted", true);
});

// Click on table row highlights bubble
function highlightFromTable(ticker) {
    d3.selectAll("tr").classed("highlighted", false);
    d3.selectAll("circle").classed("highlighted", false);
    
    d3.select(`#row-${ticker}`).classed("highlighted", true);
    d3.selectAll("circle")
        .filter(d => d.ticker === ticker)
        .classed("highlighted", true);
}
```

### Formatting Numbers
```javascript
function formatMarketCap(value) {
    if (!value) return "N/A";
    const num = parseFloat(value);
    if (num >= 1e12) return (num / 1e12).toFixed(2) + "T";
    if (num >= 1e9) return (num / 1e9).toFixed(2) + "B";
    if (num >= 1e6) return (num / 1e6).toFixed(2) + "M";
    return num.toLocaleString();
}
```

## Key Requirements Checklist
- [ ] All SVG `<circle>` elements represent individual stock bubbles only
- [ ] No auxiliary or decorative SVG circles
- [ ] Legend implemented as div element (not SVG)
- [ ] ETFs sized uniformly, no tooltip shown
- [ ] Force simulation clusters by sector using forceX/forceY
- [ ] forceCollide prevents overlap
- [ ] Ticker symbols displayed inside bubbles
- [ ] Full text without truncation
- [ ] Bidirectional highlighting between chart and table