---
name: plate-tectonics-analysis
description: Analyzing earthquake data in relation to tectonic plate boundaries using GeoJSON data.
---

# Plate Tectonics and Earthquake Analysis

## Overview
This skill covers analyzing earthquake occurrences in relation to tectonic plate boundaries, specifically identifying earthquakes within specific plates and their distances from plate boundaries.

## Data Sources

### PB2002 Plate Boundary Model
- **PB2002_boundaries.json**: Contains plate boundary lines with properties like boundary name (e.g., "PA-NA" for Pacific-North America)
- **PB2002_plates.json**: Contains plate polygon geometries with plate codes (e.g., "PA" for Pacific)

### USGS Earthquake Data
- GeoJSON format with properties: id, place, time, mag, coordinates

## Key Steps

### 1. Identify Pacific Plate Boundaries
```python
import geopandas as gpd

# Load plate boundaries
boundaries = gpd.read_file('PB2002_boundaries.json')

# Filter for Pacific plate boundaries (boundaries containing "PA")
pacific_boundaries = boundaries[
    boundaries['Name'].str.contains('PA', na=False)
]
```

### 2. Point-in-Polygon Test for Plate Membership
```python
# Load plates
plates = gpd.read_file('PB2002_plates.json')

# Get Pacific plate geometry
pacific_plate = plates[plates['Code'] == 'PA']

# Check if earthquake is within Pacific plate
earthquakes['in_pacific'] = earthquakes.geometry.within(pacific_plate.geometry.iloc[0])
```

### 3. Distance Calculation Strategy
For finding the earthquake furthest from the Pacific plate boundary:
1. Filter earthquakes to only those within the Pacific plate
2. Calculate minimum distance from each earthquake to any Pacific plate boundary segment
3. Find the maximum of these minimum distances

### 4. Handling Plate Boundary Names
Pacific plate boundaries typically have names like:
- PA-NA (Pacific - North America)
- PA-SA (Pacific - South America)  
- PA-EU (Pacific - Eurasia)
- PA-AU (Pacific - Australia)
- PA-AN (Pacific - Antarctica)
- PA-CO (Pacific - Cocos)
- PA-JF (Pacific - Juan de Fuca)

## Example Workflow
```python
# 1. Load and prepare data
earthquakes = gpd.read_file('earthquakes.json')
boundaries = gpd.read_file('boundaries.json')
plates = gpd.read_file('plates.json')

# 2. Create point geometry
earthquakes['geometry'] = gpd.points_from_xy(
    earthquakes['longitude'], 
    earthquakes['latitude']
)
earthquakes = earthquakes.set_crs('EPSG:4326')

# 3. Filter Pacific plate earthquakes
pacific_plate = plates[plates['Code'] == 'PA']
pacific_quakes = earthquakes[earthquakes.geometry.within(pacific_plate.geometry.iloc[0])]

# 4. Get Pacific boundaries
pacific_bounds = boundaries[
    boundaries['Name'].str.contains('PA', na=False)
]

# 5. Project for distance calculation
pacific_bounds_proj = pacific_bounds.to_crs('EPSG:6933')

# 6. Calculate distances
for idx, row in pacific_quakes.iterrows():
    point = gpd.GeoSeries([row['geometry']], crs='EPSG:4326').to_crs('EPSG:6933')
    dist = pacific_bounds_proj.geometry.distance(point.iloc[0]).min()
    # Store distance...
```

## Important Considerations
- Some earthquakes may be exactly on boundaries (distance ≈ 0)
- The Pacific plate is the largest oceanic plate, so interior earthquakes can be very far from boundaries
- Hawaii is a classic example of intraplate seismicity within the Pacific plate
