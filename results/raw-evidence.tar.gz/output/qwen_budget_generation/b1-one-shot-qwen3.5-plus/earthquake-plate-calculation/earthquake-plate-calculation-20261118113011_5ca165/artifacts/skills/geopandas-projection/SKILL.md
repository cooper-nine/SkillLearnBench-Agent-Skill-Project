---
name: geopandas-projection
description: Using GeoPandas for coordinate reference system transformations and geospatial distance calculations.
---

# GeoPandas Projections and Distance Calculations

## Overview
GeoPandas is a Python library that extends pandas to work with geospatial data. It provides tools for handling coordinate reference systems (CRS), performing spatial operations, and calculating distances.

## Installation
```bash
pip install geopandas shapely pyproj
```

## Key Concepts

### 1. Loading GeoJSON Data
```python
import geopandas as gpd

# Load GeoJSON file
gdf = gpd.read_file('data.geojson')
```

### 2. Understanding CRS
```python
# Check current CRS
print(gdf.crs)

# Common CRS codes:
# EPSG:4326 - WGS84 (latitude/longitude in degrees)
# EPSG:3857 - Web Mercator (meters, but distorts at poles)
# EPSG:326XX - UTM zones (meters, good for local areas)
```

### 3. Reprojecting Data
```python
# Transform to a projected CRS (e.g., World Equidistant Cylindrical for distance)
gdf_projected = gdf.to_crs('EPSG:6933')  # Equal-area projection in meters
```

### 4. Calculating Distances
For accurate distance calculations, use an appropriate projected CRS:

```python
from shapely.geometry import Point

# Create points from coordinates
points = gpd.GeoSeries([Point(lon, lat) for lon, lat in coords], crs='EPSG:4326')

# Project to a meter-based CRS
points_proj = points.to_crs('EPSG:6933')

# Calculate distance between two points
distance_meters = points_proj[0].distance(points_proj[1])
distance_km = distance_meters / 1000
```

### 5. Finding Minimum Distance to Boundary
```python
# For each point, find minimum distance to any boundary line
def min_distance_to_boundary(point_geom, boundary_gdf):
    # Ensure both are in same projected CRS
    point_proj = point_geom.to_crs(boundary_gdf.crs)
    distances = boundary_gdf.geometry.distance(point_proj.iloc[0])
    return distances.min()
```

### 6. Best Practices for Global Distance Calculations
- Use equal-area or equidistant projections like EPSG:6933 (NSIDC EASE-Grid 2.0)
- For very accurate global distances, consider using geodesic calculations with `geopy` or `pyproj.Geod`
- Always ensure all geometries are in the same CRS before calculating distances

## Example: Finding Furthest Point from Boundary
```python
import geopandas as gpd
from shapely.geometry import Point

# Load data
earthquakes = gpd.read_file('earthquakes.json')
boundaries = gpd.read_file('boundaries.json')

# Create point geometry if not present
earthquakes['geometry'] = gpd.points_from_xy(earthquakes['longitude'], earthquakes['latitude'])
earthquakes = earthquakes.set_geometry('geometry')
earthquakes = earthquakes.set_crs('EPSG:4326')

# Project boundaries to meter-based CRS
boundaries_proj = boundaries.to_crs('EPSG:6933')

# Calculate distance for each earthquake
distances = []
for idx, row in earthquakes.iterrows():
    point = gpd.GeoSeries([row['geometry']], crs='EPSG:4326').to_crs('EPSG:6933')
    dist = boundaries_proj.geometry.distance(point.iloc[0]).min()
    distances.append(dist / 1000)  # Convert to km

earthquakes['distance_km'] = distances
furthest = earthquakes.loc[earthquakes['distance_km'].idxmax()]
```
