---
name: excel-formulas
description: This skill covers Excel formula techniques including VLOOKUP, HLOOKUP, XLOOKUP, INDEX/MATCH, SUMPRODUCT for data lookup and weighted calculations.
---

# Excel Formulas for Data Lookup and Weighted Calculations

## Overview
This skill document covers essential Excel formulas for:
1. Looking up data using multiple conditions (VLOOKUP+MATCH, HLOOKUP+MATCH, XLOOKUP+MATCH, INDEX+MATCH)
2. Calculating weighted means using SUMPRODUCT
3. Statistical functions (MIN, MAX, MEDIAN, AVERAGE, PERCENTILE)

## 1. Two-Condition Lookup with INDEX and MATCH

### Syntax
```excel
=INDEX(data_range, MATCH(lookup_value1, lookup_column, 0), MATCH(lookup_value2, lookup_row, 0))
```

### Example
To find a value where column D contains a series code and row 10 contains a year:
```excel
=INDEX(Data!$A$2:$Z$50, MATCH($D12, Data!$D$2:$D$50, 0), MATCH(H$10, Data!$A$1:$Z$1, 0))
```

## 2. VLOOKUP with MATCH for Two Conditions

### Syntax
```excel
=VLOOKUP(lookup_value, table_array, MATCH(column_header, header_row, 0), FALSE)
```

### Example
```excel
=VLOOKUP($D12, Data!$A$2:$Z$50, MATCH(H$10, Data!$A$1:$Z$1, 0), FALSE)
```

## 3. XLOOKUP with MATCH (Excel 365/2021+)

### Syntax
```excel
=XLOOKUP(lookup_value, lookup_array, return_array)
```

For two conditions, nest XLOOKUP or combine with MATCH:
```excel
=XLOOKUP($D12, Data!$D$2:$D$50, XLOOKUP(H$10, Data!$A$1:$Z$1, Data!$A$2:$Z$50))
```

## 4. SUMPRODUCT for Weighted Mean

### Syntax
```excel
=SUMPRODUCT(values_range, weights_range) / SUM(weights_range)
```

### Example - Weighted Mean of Net Exports
If net exports are in H35:L40 and GDP weights are available:
```excel
=SUMPRODUCT(H35:L40, weights_range) / SUM(weights_range) * 100
```

## 5. Statistical Functions

### MIN, MAX, MEDIAN, AVERAGE
```excel
=MIN(range)
=MAX(range)
=MEDIAN(range)
=AVERAGE(range)
```

### Percentiles
```excel
=PERCENTILE.INC(range, 0.25)  // 25th percentile
=PERCENTILE.INC(range, 0.75)  // 75th percentile
```

## 6. Rounding to One Decimal Place

Use ROUND function:
```excel
=ROUND(value, 1)
```

Or multiply by 100 within the formula for percentages:
```excel
=ROUND(SUMPRODUCT(values, weights) / SUM(weights) * 100, 1)
```

## Best Practices

1. **Use absolute references** ($A$1) for ranges that should not change when copying formulas
2. **Named ranges** can make formulas more readable
3. **Error handling** with IFERROR: `=IFERROR(formula, "")`
4. **Verify data types** - ensure numeric values are not stored as text
