// Load stock descriptions data
d3.csv("/root/output/data/stock-descriptions.csv").then(function(stockData) {
    // Parse and clean data
    const stocks = stockData.map(d => ({
        ticker: d.ticker,
        sector: d.sector,
        fullName: d["full name"],
        marketCap: d.marketCap ? parseFloat(d.marketCap) : null,
        isETF: d.sector === "ETF" || !d.marketCap
    })).filter(d => d.ticker); // Filter out any rows without ticker

    // Get unique sectors (excluding ETF for coloring purposes, but include in legend)
    const sectors = [...new Set(stocks.map(d => d.sector))].filter(s => s !== "ETF");
    
    // Color scale for sectors
    const colorScale = d3.scaleOrdinal()
        .domain(sectors)
        .range(d3.schemeCategory10);

    // Create legend div
    const legendDiv = d3.select("#legend");
    sectors.forEach(sector => {
        const item = legendDiv.append("div")
            .attr("class", "legend-item");
        item.append("span")
            .attr("class", "legend-color")
            .style("background-color", colorScale(sector));
        item.append("span")
            .attr("class", "legend-text")
            .text(sector);
    });

    // Bubble chart dimensions
    const bubbleWidth = 700;
    const bubbleHeight = 600;

    // Create SVG for bubble chart
    const bubbleSvg = d3.select("#bubble-chart")
        .append("svg")
        .attr("width", bubbleWidth)
        .attr("height", bubbleHeight);

    // Scale for bubble size (market cap)
    const nonETFStocks = stocks.filter(d => !d.isETF);
    const maxMarketCap = d3.max(nonETFStocks, d => d.marketCap);
    const minMarketCap = d3.min(nonETFStocks, d => d.marketCap);
    
    const sizeScale = d3.scaleSqrt()
        .domain([minMarketCap, maxMarketCap])
        .range([15, 50]);

    // Fixed size for ETFs
    const etfSize = 25;

    // Force simulation
    const simulation = d3.forceSimulation()
        .force("charge", d3.forceManyBody().strength(-50))
        .force("collide", d3.forceCollide().radius(d => (d.isETF ? etfSize : sizeScale(d.marketCap)) + 5))
        .force("x", d3.forceX(bubbleWidth / 2).strength(0.5))
        .force("y", d3.forceY(bubbleHeight / 2).strength(0.5));

    // Add sector-based clustering forces
    const sectorCenters = {};
    sectors.forEach((sector, i) => {
        const angle = (i / sectors.length) * 2 * Math.PI;
        const radius = 150;
        sectorCenters[sector] = {
            x: bubbleWidth / 2 + radius * Math.cos(angle),
            y: bubbleHeight / 2 + radius * Math.sin(angle)
        };
    });

    // Custom force for sector clustering
    function forceSector(alpha) {
        stocks.forEach(d => {
            if (d.isETF || !sectorCenters[d.sector]) return;
            const center = sectorCenters[d.sector];
            d.x += (center.x - d.x) * alpha * 0.1;
            d.y += (center.y - d.y) * alpha * 0.1;
        });
    }

    simulation.force("sectorCluster", forceSector);

    // Create bubbles
    const bubbles = bubbleSvg.selectAll("circle")
        .data(stocks)
        .enter()
        .append("circle")
        .attr("r", d => d.isETF ? etfSize : sizeScale(d.marketCap))
        .attr("fill", d => d.isETF ? "#cccccc" : colorScale(d.sector))
        .attr("stroke", "#333")
        .attr("stroke-width", 1)
        .attr("class", "bubble")
        .on("click", function(event, d) {
            highlightStock(d.ticker);
        })
        .on("mouseover", function(event, d) {
            if (!d.isETF) {
                showTooltip(event, d);
            }
        })
        .on("mouseout", hideTooltip);

    // Add ticker labels inside bubbles
    const labels = bubbleSvg.selectAll("text")
        .data(stocks)
        .enter()
        .append("text")
        .attr("class", "bubble-label")
        .attr("text-anchor", "middle")
        .attr("dy", ".3em")
        .text(d => d.ticker);

    // Tooltip element
    const tooltip = d3.select("#tooltip");

    function showTooltip(event, d) {
        tooltip.style("opacity", 1)
            .html(`
                <strong>${d.ticker}</strong><br/>
                ${d.fullName}<br/>
                Sector: ${d.sector}
            `)
            .style("left", (event.pageX + 10) + "px")
            .style("top", (event.pageY - 10) + "px");
    }

    function hideTooltip() {
        tooltip.style("opacity", 0);
    }

    // Update positions on simulation tick
    simulation.nodes(stocks).on("tick", () => {
        bubbles
            .attr("cx", d => d.x)
            .attr("cy", d => d.y);
        
        labels
            .attr("x", d => d.x)
            .attr("y", d => d.y);
    });

    // Create data table
    const tableContainer = d3.select("#data-table");
    const table = tableContainer.append("table")
        .attr("class", "stock-table");

    // Table header
    const thead = table.append("thead");
    const headerRow = thead.append("tr");
    ["Ticker symbol", "Full company name", "Sector", "Market cap"].forEach(col => {
        headerRow.append("th").text(col);
    });

    // Table body
    const tbody = table.append("tbody");
    
    stocks.forEach((stock, index) => {
        const row = tbody.append("tr")
            .attr("class", "stock-row")
            .attr("data-ticker", stock.ticker)
            .on("click", function() {
                highlightStock(stock.ticker);
            });
        
        row.append("td").text(stock.ticker);
        row.append("td").text(stock.fullName);
        row.append("td").text(stock.sector);
        row.append("td").text(formatMarketCap(stock.marketCap));
    });

    // Format market cap
    function formatMarketCap(cap) {
        if (cap === null || cap === undefined) return "N/A";
        if (cap >= 1e12) return (cap / 1e12).toFixed(2) + "T";
        if (cap >= 1e9) return (cap / 1e9).toFixed(2) + "B";
        if (cap >= 1e6) return (cap / 1e6).toFixed(2) + "M";
        return cap.toFixed(2);
    }

    // Highlight function for connecting chart and table
    function highlightStock(ticker) {
        // Remove previous highlights
        d3.selectAll(".bubble").classed("highlighted", false);
        d3.selectAll(".stock-row").classed("highlighted", false);

        // Highlight bubble
        d3.selectAll(".bubble")
            .filter(d => d.ticker === ticker)
            .classed("highlighted", true);

        // Highlight table row
        d3.selectAll(".stock-row")
            .filter(function() {
                return d3.select(this).attr("data-ticker") === ticker;
            })
            .classed("highlighted", true);

        // Scroll table row into view
        const row = document.querySelector(`.stock-row[data-ticker="${ticker}"]`);
        if (row) {
            row.scrollIntoView({ behavior: "smooth", block: "nearest" });
        }
    }

}).catch(function(error) {
    console.error("Error loading data:", error);
});
